./xenblocksMiner
