#!/usr/bin/env bash

#hash=$(cpu-temp)
#hash=$(cat hashrate.txt)
hash=$(paste -d+ /hive/miners/custom/xengpuminer/hash_rates/* | bc)
khs=$(echo $hash | awk '{print $1/1000}')
echo "khs: $khs"


gpu_busid=$(cat /var/run/hive/gpu-detect.json | jq -r '.[] | select((.brand=="nvidia" or .brand=="amd")) | .busid' | cut -d ':' -f 1)
uptime=$(ps a -o etime,cmd | grep "miner.sh" | awk '!/awk/ {split($1, a, "[-:]"); time = 0; for (i = 1; i <= 4; i++) if (a[i] != "") time = time * 60 + a[i]; print time}' | head -n 1)
#uptime=$(ps -eo etime,cmd | awk -v process_name="SCREEN -S" '$0 ~ process_name {split($1, time, ":"); print (time[1]*3660 + time[2]*60 + time[3])}') echo "$uptime"

#inicjalizacja pustej tablicy hs
hs=()
#petla po plikach w katalogu
for file in /hive/miners/custom/xengpuminer/hash_rates/*; do
    if [ -f "$file" ]; then
    value=$(cat "$file" | awk '{printf "%.2f", $1}')
    hs+=("$value")
fi
done
#konwersja tablicy hs do formatu JSON
hs_json=$(IFS=,; echo "[${hs[*]}]")



# Zamiana gpu_id danych na tablicę JSON 
gpu_busid_json="[" 
first=true

while read -r line; do
    decimal_value=$((16#$line))
     if [ "$first" = true ]; then
         gpu_busid_json+="$decimal_value"
         first=false
     else
         gpu_busid_json+=", $decimal_value"
     fi
 done <<< "$gpu_busid"
gpu_busid_json+="]"

stats='{"hs": '$hs_json',"hs_units": "hs", "uptime": '$uptime', "ver": "levykrak@gmail.com", "algo": "argon2id", "bus_numbers": '$gpu_busid_json'}'
#stats1='{"hs": [1.80,952.43,957.27,955.99,949.11,963.41,955.70,955.89,957.87,511.89,960.90,947.46],"hs_units": "hs", "uptime": '$uptime', "ver": "dupajas", "algo": "xenblock", "bus_numbers": '$gpu_busid_json'}'
echo "stats: $stats"
#echo "$stats1"
