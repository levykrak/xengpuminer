miner.sh -g 12
