#!/usr/bin/env bash

#function miner_config_gen() {
#  local MINER_CONFIG="$MINER_DIR/$MINER_VER/$MINER_NAME.conf"
#  mkfile_from_symlink $MINER_CONFIG

#generating config
echo "[Settings]
difficulty = 1
memory_cost = 1500
cores = 1
account = $CUSTOM_TEMPLATE
last_block_url = http://xenminer.mooo.com:4445/getblocks/lastblock
gpu_mode = true
dev_fee_on = false"   > /hive/miners/custom/xengpuminer/config.conf
  

echo "miner.sh $CUSTOM_USER_CONFIG" > /hive/miners/custom/xengpuminer/h-run.sh
